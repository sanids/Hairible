//
//  CameraViewController.h
//  CameraViewController
//
//  Created by Alex Littlejohn on 2016/04/01.
//  Copyright © 2016 zero. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CameraViewController.
FOUNDATION_EXPORT double CameraViewControllerVersionNumber;

//! Project version string for CameraViewController.
FOUNDATION_EXPORT const unsigned char CameraViewControllerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CameraViewController/PublicHeader.h>


